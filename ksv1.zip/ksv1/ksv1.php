<?php
/*
Plugin Name: ksv1
Description: Un petit plugin pour gérer un slider avec l'utilsation des articles.
Version: 1.0
Author: Nicolas
License: GPL
*/
?>

<?php

include 'inc/button.php';
include 'inc/shortcode.php';
/*add_action('init', 'ksv1_init');*/
/*function ksv1_init() {

    $arg = array('description' => "Gestion du slider");
    $new_cat_id = wp_insert_term("slider", "category", $arg);

}*/

function ksv1_show($catname = '') {
    wp_deregister_script('jquery');
    wp_enqueue_script('jquery','https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js',null,'1.7.2',true);
    wp_enqueue_script('caroufredsel',plugins_url().'/ksv1/js/caroufredsel.js',array('jquery'),'6.2.0',true);
    add_action('wp_footer', 'ksv1_script', 30);
    wp_enqueue_style('style',plugins_url('style.css', __FILE__) );

    
    
    $query = new WP_Query( 'category_name='. $catname .'' );
    
    ?> 
<div id="wrapper">
    <div id="inner">
        <div id="carousel">
            <?php 
            if ( $query->have_posts() ) {
                while ( $query->have_posts() ) {
                    $query->the_post();
                    $url = wp_get_attachment_url( get_post_thumbnail_id() );
                    echo '<img src="'. $url .'" alt="'. get_post_thumbnail_id() .'" width="600" height="400" />';
                }                   
            }else{
                echo wpautop( 'Désolé, aucun article trouvé' );
            }
            ?>
        </div>
    	<div id="navi">
            <div id="timer"></div>
            <a id="prev" href="#"></a>
            <a id="play" href="#"></a>
            <a id="next" href="#"></a>
        </div>
    </div>
</div>


    <?php
}

function ksv1_script() {
?>
<script type="text/javascript">
 
(function($){
          $(function() {
    $('#carousel').carouFredSel({
    prev: '#prev',
    next: '#next',
    auto: {
    button: '#play',
    progress: '#timer',
    pauseOnEvent: 'resume'
    },
    scroll: {
    fx: 'fade'
    }
    });
    $('#wrapper').hover(function() {
    $('#navi').stop().animate({
    bottom: 0
    });
    }, function() {
    $('#navi').stop().animate({
    bottom: -60
    });
    });
    });
})(jQuery);
</script>
    <?php
}

?>