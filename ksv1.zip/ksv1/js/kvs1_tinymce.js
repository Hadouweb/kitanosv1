tinymce.create('tinymce.plugins.ksv1',{
    init : function(ed,url){
        ed.addButton('ksv1',{
            title : 'Add Slider',
            image : url + '/ksv1.png',
            onclick : function(){
                var kvscategory = prompt('Choose the category slider', '');
                ed.selection.setContent('[ksv1 cat='+kvscategory+']');                
            }
        });
    },
    createControl : function(n, cm){
        return null;
    }
});
tinymce.PluginManager.add('ksv1',tinymce.plugins.ksv1);
    



