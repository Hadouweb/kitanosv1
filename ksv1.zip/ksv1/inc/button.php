<?php
    add_action('init','add_buttons');
    function add_buttons(){
        if(current_user_can('edit_posts') && current_user_can('edit_pages')){
            add_filter('mce_external_plugins','add_plugins');
            add_filter('mce_buttons','register_buttons');               
        }
    }
    
    function add_plugins($plugins){
        $plugins['ksv1'] = plugins_url().'/ksv1/js/kvs1_tinymce.js';
        return $plugins;
    }
    
    function register_buttons($buttons){
        array_push($buttons,'ksv1');
        return $buttons;
    }
?>
