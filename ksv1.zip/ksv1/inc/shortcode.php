<?php
add_shortcode( 'ksv1', 'ksv1_shortcode');
function ksv1_shortcode( $atts ) {
    extract(shortcode_atts( array(
        'cat' => ''
    ), $atts) );
    
    return ksv1_show($catname = $cat);
}
?>
